# libunwindstack-ndk

This repository contains a patched version of libunwindstack to build for NDK.
It's originally based on the work of ivanarh ([libunwindstack-ndk](https://github.com/ivanarh/libunwindstack-ndk)).

Because not everything builds on android or is no longer useful (MIPS support,
GNU debug info for symbolication) we removed it from the codebase.
